SPRITING LIST:

    Blast Furnace: Done
    Cartography Table: Needs a bit of fixing
    Chest
    Crafter
    Crafting Table: Done
    Dispenser
    Dropper
    Enchant
    Furnace: Done
    Grindstone
    Hopper
    Inventory
    Anvil: Done
    Shulker Box
    Smoker: Done
    Stonecutter
    Smithing Table